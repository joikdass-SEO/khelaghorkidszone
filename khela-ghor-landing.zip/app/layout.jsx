import { Analytics } from '@vercel/analytics/next'
import './globals.css'

export const metadata = {
  title: 'খেলা ঘর | Indoor Playground',
  description: 'নিরাপদ, রঙিন আর মজার এক দুনিয়া—খেলা ঘর ইনডোর প্লেগ্রাউন্ডে ছোট্টদের বড় আনন্দ।',
  generator: 'v0.app',
}

export const viewport = {
  colorScheme: 'light',
  themeColor: '#fff9e9',
  userScalable: true,
}

export default function RootLayout({ children }) {
  return <html lang="bn"><body>{children}{process.env.NODE_ENV === 'production' && <Analytics />}</body></html>
}
