'use client'

import { useState } from 'react'
import { ArrowRight, CalendarDays, Check, Clock3, MapPin, MessageCircle, Phone, Sparkles, Star, Ticket, Users } from 'lucide-react'

const logoUrl = 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-HiMJByLdmg8HWKB4fdckISKsMitzpH.png'
const promoUrl = 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-RJELG04hKb4Dp5ZPRajLoEpJIxhu7m.png'

const galleryImages = [1, 2, 3, 4, 5, 6, 7, 8, 9].map((number) => ({ src: `/playground-${number}.png`, alt: `খেলা ঘরের খেলার ছবি ${number}` }))

const plans = [
  { hours: '১ ঘণ্টা', price: '৳১০০', tone: 'pink', note: 'একটু খেলি!' },
  { hours: '২ ঘণ্টা', price: '৳২০০', tone: 'blue', note: 'আরও মজা!' },
  { hours: 'আনলিমিটেড', price: '৳৩৫০', tone: 'green', note: 'দিনভর আনন্দ!' },
]

export default function Page() {
  const [booked, setBooked] = useState(false)

  return (
    <main className="site-shell">
      <nav className="nav-wrap" aria-label="Main navigation">
        <a className="brand" href="#top" aria-label="Khela Ghor home">
          <img src={logoUrl} alt="Khela Ghor colorful castle and unicorn logo" />
          <span><strong>খেলা ঘর</strong><small>Indoor Playground</small></span>
        </a>
        <div className="nav-links">
          <a href="#why">কেন খেলা ঘর?</a>
          <a href="#pricing">দাম</a>
          <a href="#offers">অফার</a>
          <a href="#photos">ছবি</a>
          <a href="#visit">যোগাযোগ</a>
        </div>
        <a className="nav-cta" href="#pricing">বুকিং করুন <ArrowRight aria-hidden="true" /></a>
      </nav>

      <section className="hero" id="top">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles aria-hidden="true" /> ছোট্টদের বড় আনন্দের ঠিকানা</div>
          <h1>খেলতে খেলতে<br /><span>হাসুক</span> আপনার সোনা।</h1>
          <p>নিরাপদ, রঙিন আর মজার এক দুনিয়া—যেখানে প্রতিটি দিন হয়ে ওঠে নতুন অ্যাডভেঞ্চার।</p>
          <div className="hero-actions">
            <a className="primary-btn" href="#pricing">আজই খেলতে আসুন <ArrowRight aria-hidden="true" /></a>
            <a className="text-btn" href="#why">কী আছে দেখুন <span>↓</span></a>
          </div>
          <div className="trust-row">
            <div className="avatar-stack"><span>👧</span><span>👦</span><span>🧒</span></div>
            <div><strong>৫০০+ খুশি পরিবার</strong><small>প্রতিদিন আমাদের সঙ্গে</small></div>
          </div>
        </div>
        <div className="hero-art">
          <div className="sun-burst" aria-hidden="true"></div>
          <div className="hero-card"><img src={logoUrl} alt="Colorful Khela Ghor playzone illustration" /></div>
          <div className="floating-note note-one"><Star aria-hidden="true" fill="currentColor" /> মজা নিশ্চিত!</div>
          <div className="floating-note note-two"><span>☀</span> নিরাপদে খেলুন</div>
          <div className="squiggle" aria-hidden="true">〰</div>
        </div>
      </section>

      <section className="marquee" aria-label="Khela Ghor highlights"><span>খেলা</span><i>✦</i><span>হাসি</span><i>✦</i><span>আনন্দ</span><i>✦</i><span>অ্যাডভেঞ্চার</span><i>✦</i><span>খেলা</span></section>

      <section className="why-section" id="why">
        <div className="section-heading"><div><p className="section-kicker">কেন আমাদের বেছে নেবেন?</p><h2>এক জায়গায়,<br /><em>অনেক আনন্দ।</em></h2></div><p className="section-intro">আপনার সন্তানের হাসিই আমাদের সবচেয়ে বড় পুরস্কার। তাই প্রতিটি কোণ সাজানো হয়েছে যত্ন আর ভালোবাসায়।</p></div>
        <div className="feature-grid">
          <article className="feature-card feature-yellow"><div className="feature-icon">🛝</div><h3>খেলার পাহাড়</h3><p>স্লাইড, বলপিট আর ক্লাইম্বিং—অফুরন্ত মজার আয়োজন।</p></article>
          <article className="feature-card feature-pink"><div className="feature-icon">🛡️</div><h3>নিরাপদে খেলুন</h3><p>নরম ফ্লোর, পরিচ্ছন্ন পরিবেশ আর সবসময় নজরদারি।</p></article>
          <article className="feature-card feature-blue"><div className="feature-icon">🎈</div><h3>পার্টি স্পট</h3><p>জন্মদিন হোক বা ছোট্ট কোনো উৎসব—সব আয়োজন একসাথে।</p></article>
        </div>
      </section>

      <section className="pricing-section" id="pricing">
        <div className="pricing-copy"><p className="section-kicker">সবার জন্য সাশ্রয়ী</p><h2>আজকের খেলায়<br /><em>সেরা অফার!</em></h2><p>আপনার পছন্দের প্যাকেজ বেছে নিন। বেশি সময়, বেশি হাসি, বেশি স্মৃতি!</p><div className="price-list">{plans.map((plan) => <div className={`price-row ${plan.tone}`} key={plan.hours}><div className="price-hours"><Clock3 aria-hidden="true" /><span>{plan.hours}</span></div><strong>{plan.price}</strong><small>{plan.note}</small></div>)}</div><button className="primary-btn full-btn" onClick={() => setBooked(true)}>{booked ? 'বুকিং রিকোয়েস্ট নেওয়া হয়েছে!' : 'এখনই বুকিং করুন'} <Ticket aria-hidden="true" /></button></div>
        <div className="promo-art"><img src={promoUrl} alt="Khela Ghor special playtime offer with one hour, two hour and unlimited pricing" /><div className="promo-caption"><span>প্রতিদিন</span><strong>হাসির নতুন কারণ</strong></div></div>
      </section>

      <section className="offer-section" id="offers"><div className="offer-badge"><Sparkles aria-hidden="true" /><span>এই সপ্তাহের স্পেশাল</span></div><div className="offer-content"><p className="section-kicker">সীমিত সময়ের অফার</p><h2>দুই ঘণ্টা খেলুন,<br /><em>তৃতীয় ঘণ্টা ফ্রি!</em></h2><p>বন্ধুদের নিয়ে দল বেঁধে আসুন আর উপভোগ করুন আরও বেশি সময়ের আনন্দ। এই অফারটি শুধুমাত্র শুক্রবার ও শনিবারে প্রযোজ্য।</p><div className="offer-details"><span><Clock3 aria-hidden="true" /> সকাল ১০টা – রাত ৮টা</span><span><Ticket aria-hidden="true" /> প্রতি শিশুর জন্য</span></div><a className="offer-btn" href="#booking">অফারটি নিতে বুক করুন <ArrowRight aria-hidden="true" /></a></div><img src={promoUrl} alt="খেলা ঘরের বিশেষ অফার" /></section>

      <section className="story-section">
        <div className="story-art"><img src={logoUrl} alt="খেলা ঘরের রঙিন খেলার জগত" /><div className="story-sticker">প্রতিটি দিন<br /><strong>নতুন গল্প!</strong></div></div>
        <div className="story-copy"><p className="section-kicker">খেলা ঘর সম্পর্কে</p><h2>শুধু খেলা নয়,<br /><em>শৈশবের স্মৃতি।</em></h2><p>খেলা ঘর হলো ছোট্টদের জন্য তৈরি একটি উষ্ণ, নিরাপদ এবং আনন্দে ভরা ইনডোর প্লে-জোন। এখানে শিশুরা নিজের মতো করে দৌড়াতে, লাফাতে, বন্ধু বানাতে এবং নতুন কিছু শিখতে পারে। আমাদের প্রতিটি খেলনা, প্রতিটি রঙ আর প্রতিটি কোণ সাজানো হয়েছে শিশুদের কল্পনা ও আনন্দকে সামনে রেখে।</p><p>পরিষ্কার-পরিচ্ছন্ন পরিবেশ, নরম সেফটি ফ্লোর এবং দায়িত্বশীল কেয়ার টিমের নজরদারিতে আপনার সন্তান খেলবে নিশ্চিন্তে। বাবা-মায়ের জন্যও আছে আরাম করে বসে ছোট্��� সোনা��� হাসি দেখার সুন্দর জায়গা।</p><div className="check-list"><span><Check aria-hidden="true" /> প্রতিদিন পরিষ্কার ও নিরাপদ</span><span><Check aria-hidden="true" /> প্রশিক্ষিত কেয়ার টিম</span></div></div>
      </section>

      <section className="photo-section" id="photos"><div className="section-heading"><div><p className="section-kicker">আমাদের রঙিন দুনিয়া</p><h2>ছবিতে ছবিতে<br /><em>খুশির মুহূর্ত।</em></h2></div><p className="section-intro">খেলা ঘরের প্রতিটি কোণেই আছে নতুন ��িছু আবিষ্কারের আনন্দ। আসুন, এক নজরে দেখে নিন।</p></div><div className="photo-grid">{galleryImages.map((image, index) => <img className={index === 0 ? 'photo-large' : ''} key={image.src} src={image.src} alt={image.alt} />)}</div><article className="seo-description"><p className="section-kicker">কেন খেলা ঘর?</p><h2>Best Indoor Kids Playzone in Bangladesh</h2><p>খেলা ঘর বাংলাদেশের অন্যতম সেরা ইনডোর কিডস প্লে-জোন, যেখানে শিশুদের আনন্দ, নিরাপত্তা এবং সৃজনশীল বিকাশকে সবচেয়ে বেশি গুরুত্ব দেওয়া হয়। ঢাকার প্রাণকেন্দ্রে আমাদের রঙিন পরিবেশে রয়েছে বল পিট, স্লাইড, ক্লাইম্বিং জোন, সফট প্লে এরিয়া এবং কল্পনার রাজ্য—যা প্রতিটি শিশুর জন্য তৈরি করে স্মরণীয় অভিজ্ঞতা।</p><p>আমরা বিশ্বাস করি, খেলাই শিশুর শেখার সবচেয়ে আনন্দের উপায়। তাই প্রতিটি জোন এমনভাবে সাজানো হয়েছে যাতে শিশুরা খেলতে খেলতে আত্মবিশ্বাস, বন্ধুত্ব, ভারসাম্য ও সমস্যা সমাধানের দক্ষতা গড়ে তুলতে পারে। নিয়মিত পরিষ্কার-পরিচ্ছন্নতা, নরম সেফটি ফ্লোর এবং প্রশিক্ষিত কেয়ার টিমের কারণে বাবা-মায়েরাও থাকেন নিশ্চিন্ত। জন্মদিন, স্কুল ট্রিপ কিংবা পরিবারের সঙ্গে ছুটির দিনের জন্য খেলা ঘরই হতে পারে আপনার শিশুর প্রিয় ঠিকানা।</p></article></section>

      <section className="booking-section" id="booking"><div className="booking-copy"><p className="section-kicker">আজই চলে আসুন</p><h2>আপনার ছোট্ট<br /><em>অ্যাডভেঞ্চার বুক করুন।</em></h2><p>ফর্মটি পূরণ করুন, আমাদের টিম আপনাকে কল করে সময় নিশ্চিত করবে।</p><div className="booking-perks"><span><CalendarDays aria-hidden="true" /> পছন্দের দিন</span><span><Clock3 aria-hidden="true" /> সুবিধাজনক সময়</span><span><Ticket aria-hidden="true" /> সহজ বুকিং</span></div></div><form className="booking-form" onSubmit={(event) => { event.preventDefault(); setBooked(true) }}><label>আপনার নাম<input required placeholder="যেমন: আয়েশা রহমান" /></label><label>ফোন নম্বর<input required type="tel" placeholder="০১৭০০-০০০০০০" /></label><div className="form-row"><label>কতজন শিশু?<select defaultValue="1"><option value="1">১ জন</option><option value="2">২ জন</option><option value="3">৩ জন</option><option value="4">৪+ জন</option></select></label><label>কোন প্যাকেজ?<select defaultValue="1"><option value="1">১ ঘণ্টা — ৳১০০</option><option value="2">২ ঘণ্টা — ৳২০০</option><option value="3">আনলিমিটেড — ৳৩৫০</option></select></label></div><button className="primary-btn full-btn" type="submit">{booked ? 'বুকিং রিকোয়েস্ট পাঠানো হয়েছে!' : 'বুকিং রিকোয়েস্ট পাঠান'} <ArrowRight aria-hidden="true" /></button></form></section>

      <section className="faq-section" id="faq"><div className="section-heading"><div><p className="section-kicker">জানতে চান?</p><h2>আপনার প্রশ্ন,<br /><em>আমাদের উত্তর।</em></h2></div><p className="section-intro">খেলা ঘরে আসার আগে প্রয়োজনীয় সব তথ্য একসাথে জেনে নিন।</p></div><div className="faq-list"><details open><summary>খেলা ঘরে আসার জন্য কি আগে থেকে বুকিং করতে হবে?</summary><p>আগে থেকে বুকিং করলে আপনার পছন্দের সময় নিশ্চিত থাকে। তবে জায়গা থাকলে সরাসরি এসেও খেলতে পারবেন।</p></details><details><summary>কোন বয়সের শিশুরা খেলতে পারবে?</summary><p>সাধারণত ১ থেকে ১২ বছর বয়সী শিশুরা খেলা ঘরের বিভিন্ন জোনে আনন্দ করতে পারবে।</p></details><details><summary>বাবা-মায়েরা কি ভেতরে থাকতে পারবেন?</summary><p>অবশ্যই। নির্দিষ্ট প্যারেন্ট লাউঞ্জ থেকে আপনি আরামে শিশুর খেলা দেখতে পারবেন।</p></details><details><summary>জন্মদিনের পার্টি আয়োজন করা যায়?</summary><p>হ্যাঁ, আমাদের পার্টি স্পটে জন্মদিন বা ছোট আয়োজনের জন্য বিশেষ প্যাকেজ আছে। বিস্তারিত জানতে ফোন করুন।</p></details><details><summary>খেলা ঘরের সময়সূচি কী?</summary><p>প্রতিদিন সকাল ১০টা থেকে রাত ৮টা পর্যন্ত খেলা ঘর খোলা থাকে।</p></details><details><summary>প্রবেশের জন্য কী পোশাক পরা ভালো?</summary><p>আরামদায়ক পোশাক ও গ্রিপযুক্ত মোজা পরলে শিশুরা আরও স্বাচ্ছন্দ্যে খেলতে পারবে।</p></details><details><summary>খাবার বা পানীয় নিয়ে আসা যাবে?</summary><p>খেলার জায়গায় খাবার না নেওয়াই ভালো। আমাদের নির্দিষ্ট বসার জায়গায় পানি ও হালকা খাবার নেওয়া যায়।</p></details><details><summary>প্যাকেজের মেয়াদ শেষ হলে অতিরিক্ত সময় নেওয়া যাবে?</summary><p>জায়গা খালি থাকলে অতিরিক্ত সময় নেওয়া যায়। আমাদের টিম আপনাকে বর্তমান রেট জানিয়ে দেবে।</p></details></div></section>

      <section className="contact-section" id="contact"><div><p className="section-kicker">যোগাযোগ করুন</p><h2>আজই আসুন,<br /><em>খুশি নিয়ে ফিরুন।</em></h2><p>আপনার প্রশ্ন বা বুকিংয়ের জন্য আমাদের সঙ্গে কথা বলুন। খেলা ঘরের টিম আপনাকে সাহায্য করতে প্রস্তুত।</p></div><div className="contact-card"><div><MapPin aria-hidden="true" /><span><strong>ঠিকানা</strong>ঢাকা, বাংলাদেশ</span></div><div><Clock3 aria-hidden="true" /><span><strong>খোলার সময়</strong>সকাল ১০টা – রাত ৮টা</span></div><div><Phone aria-hidden="true" /><span><strong>ফোন করুন</strong>০১৭০০-০০০০০০</span></div></div></section>

      <footer className="site-footer" id="visit"><div className="footer-main"><div className="footer-about"><a className="brand footer-brand" href="#top"><img src={logoUrl} alt="Khela Ghor logo" /><span><strong>খেলা ঘর</strong><small>Indoor Playground</small></span></a><p>ছোট্টদের হাসি, আমাদের আনন্দ। নিরাপদ, পরিষ্কার আর রঙিন এক জগতে প্রতিটি শিশুর জন্য তৈরি নতুন নতুন আনন্দ।</p></div><div className="footer-column"><strong>দ্রুত লিংক</strong><a href="#pricing">দাম</a><a href="#photos">ছবি</a><a href="#booking">বুকিং</a><a href="#faq">জিজ্ঞাসা</a></div><div className="footer-column"><strong>যোগাযোগ</strong><span><MapPin aria-hidden="true" /> ঢাকা, বাংলাদেশ</span><span><Clock3 aria-hidden="true" /> সকাল ১০টা – রাত ৮টা</span><a href="tel:+8801700000000"><Phone aria-hidden="true" /> ০১৭০০-০০০০০০</a></div></div><div className="footer-bottom"><span>© ২০২৬ খেলা ঘর। সর্বস্বত্ব সংরক্ষিত।</span><span><Users aria-hidden="true" /> নিরাপদে খেলুন, আনন্দে থাকুন</span></div></footer>
      <div className="floating-contact" aria-label="দ্রুত যোগাযোগ"><a className="floating-btn whatsapp-btn" href="https://wa.me/8801700000000" target="_blank" rel="noreferrer" aria-label="WhatsApp-এ যোগাযোগ করুন"><MessageCircle aria-hidden="true" /><span>WhatsApp</span></a><a className="floating-btn call-btn" href="tel:+8801700000000" aria-label="ফোনে যোগাযোগ করুন"><Phone aria-hidden="true" /><span>Call Now</span></a></div>
    </main>
  )
}
